class SeatInventorySystem {
    private boolean connected = false;

    public void connectToReservationServer() {
        this.connected = true;
        System.out.println("[SeatInventory] Connected to central seat server.");
    }

    public boolean isSeatAvailable(String flightCode, String seatNumber) {
        if (!connected) {
            throw new IllegalStateException("SeatInventorySystem is not connected.");
        }
        if (seatNumber == null || seatNumber.trim().isEmpty()) {
            return false;
        }
        return !seatNumber.toUpperCase().startsWith("13");
    }

    public String lockSeat(String flightCode, String seatNumber, String passengerName) {
        if (!isSeatAvailable(flightCode, seatNumber)) {
            throw new IllegalArgumentException("Seat " + seatNumber + " cannot be locked.");
        }
        String lockToken = "LOCK-" + flightCode.toUpperCase() + "-" + seatNumber.toUpperCase();
        System.out.println("[SeatInventory] Locked seat " + seatNumber + " for " + passengerName + " (" + lockToken + ")");
        return lockToken;
    }

    public void releaseSeatLock(String lockToken) {
        if (connected && lockToken != null) {
            System.out.println("[SeatInventory] Released lock: " + lockToken);
        }
    }

    public void disconnect() {
        this.connected = false;
        System.out.println("[SeatInventory] Disconnected from seat server.");
    }
}

class BaggagePricingEngine {

    public double calculateBaggageFeeUSD(int bagCount, double totalWeightKg) {
        if (bagCount < 0 || totalWeightKg < 0) {
            throw new IllegalArgumentException("Bag count and weight cannot be negative.");
        }
        if (bagCount == 0) {
            System.out.println("[BaggageEngine] No checked bags. Fee: $0.00");
            return 0.0;
        }

        double fee = 0.0;
        if (bagCount > 1) {
            fee += (bagCount - 1) * 35.0;
        }
        if (totalWeightKg > 20.0) {
            double extraKg = totalWeightKg - 20.0;
            fee += extraKg * 12.0;
        }
        System.out.printf("[BaggageEngine] Calculated baggage fee: $%.2f%n", fee);
        return fee;
    }
}

class CurrencyConverter {

    public double convertFromUSD(double amountUSD, String targetCurrency) {
        if (targetCurrency == null) {
            throw new IllegalArgumentException("Target currency cannot be null.");
        }
        String code = targetCurrency.trim().toUpperCase();
        double rate;

        switch (code) {
            case "USD":
                rate = 1.0;
                break;
            case "EUR":
                rate = 0.92;
                break;
            case "GBP":
                rate = 0.79;
                break;
            case "KZT":
                rate = 485.0;
                break;
            default:
                throw new IllegalArgumentException("Unsupported currency code: " + code);
        }

        double converted = amountUSD * rate;
        System.out.printf("[CurrencyConverter] %.2f USD -> %.2f %s%n", amountUSD, converted, code);
        return converted;
    }
}

class PaymentProcessor {
    private boolean gatewayReady = false;
    private String activePromoCode = null;

    public void initializeGateway() {
        this.gatewayReady = true;
        System.out.println("[PaymentProcessor] Payment gateway initialized.");
    }

    public void applyPromoCode(String promoCode) {
        if (!gatewayReady) {
            throw new IllegalStateException("Initialize gateway before applying promo codes.");
        }
        this.activePromoCode = promoCode;
        System.out.println("[PaymentProcessor] Applied promo code: " + promoCode);
    }

    public String chargeCard(String cardNumber, double amount, String currency) {
        if (!gatewayReady) {
            throw new IllegalStateException("Payment gateway is not initialized.");
        }
        if (cardNumber == null || cardNumber.replaceAll("\s+", "").length() < 12) {
            throw new IllegalArgumentException("Invalid card number provided.");
        }

        double finalAmount = amount;
        if ("SILVER-FREE-BAG".equalsIgnoreCase(activePromoCode)) {
            finalAmount = amount * 0.90;
            System.out.printf("[PaymentProcessor] Promo discount applied. New total: %.2f %s%n", finalAmount, currency);
        }

        this.activePromoCode = null;

        String txId = "TX-" + Math.abs((cardNumber + finalAmount).hashCode());
        System.out.printf("[PaymentProcessor] Charged %.2f %s | Receipt: %s%n", finalAmount, currency, txId);
        return txId;
    }
}

class TicketIssuer {

    public String generateTicket(String passengerName, String flightCode, String seatLockToken, String paymentReceiptId) {
        if (seatLockToken == null || paymentReceiptId == null) {
            throw new IllegalStateException("Cannot issue ticket without seat lock and payment.");
        }
        String ticketCode = "ETKT-" + flightCode.toUpperCase() + "-" + paymentReceiptId.substring(3);
        System.out.println("[TicketIssuer] Issued " + ticketCode + " for " + passengerName);
        return ticketCode;
    }
}

class FlightBookingFacade {

    private static final String STANDARD = "STANDARD";
    private static final String SILVER = "SILVER";
    private static final String GOLD = "GOLD";
    private static final String SILVER_PROMO = "SILVER-FREE-BAG";

    private final SeatInventorySystem seatSystem;
    private final BaggagePricingEngine baggageEngine;
    private final CurrencyConverter currencyConverter;
    private final PaymentProcessor paymentProcessor;
    private final TicketIssuer ticketIssuer;

    public FlightBookingFacade() {
        this.seatSystem = new SeatInventorySystem();
        this.baggageEngine = new BaggagePricingEngine();
        this.currencyConverter = new CurrencyConverter();
        this.paymentProcessor = new PaymentProcessor();
        this.ticketIssuer = new TicketIssuer();
    }

    public String bookFlight(String passengerName, String flightCode, String seatNumber,
                             double baseFareUSD, int bagCount, double bagWeightKg,
                             String currency, String cardNumber) {
        return bookFlight(passengerName, flightCode, seatNumber, baseFareUSD,
                bagCount, bagWeightKg, currency, cardNumber, STANDARD);
    }

    public String bookFlight(String passengerName, String flightCode, String seatNumber,
                             double baseFareUSD, int bagCount, double bagWeightKg,
                             String currency, String cardNumber, String loyaltyTier) {
        String lockToken = null;
        try {
            String tier = normalizeTier(loyaltyTier);

            seatSystem.connectToReservationServer();
            lockToken = seatSystem.lockSeat(flightCode, seatNumber, passengerName);

            double totalUSD = baseFareUSD;
            if (!isBaggageExempt(tier)) {
                totalUSD += baggageEngine.calculateBaggageFeeUSD(bagCount, bagWeightKg);
            }

            double convertedTotal = currencyConverter.convertFromUSD(totalUSD, currency);

            paymentProcessor.initializeGateway();
            if (SILVER.equals(tier)) {
                paymentProcessor.applyPromoCode(SILVER_PROMO);
            }
            String receiptId = paymentProcessor.chargeCard(cardNumber, convertedTotal, currency);

            return ticketIssuer.generateTicket(passengerName, flightCode, lockToken, receiptId);
        } catch (RuntimeException ex) {
            if (lockToken != null) {
                seatSystem.releaseSeatLock(lockToken);
            }
            System.out.println("[Facade] Booking failed for " + passengerName + ": " + ex.getMessage());
            return "BOOKING_FAILED: " + ex.getMessage();
        } finally {
            seatSystem.disconnect();
        }
    }

    private String normalizeTier(String loyaltyTier) {
        if (loyaltyTier == null) {
            return STANDARD;
        }
        String tier = loyaltyTier.trim().toUpperCase();
        if (!tier.equals(STANDARD) && !tier.equals(SILVER) && !tier.equals(GOLD)) {
            throw new IllegalArgumentException("Unsupported loyalty tier: " + tier);
        }
        return tier;
    }

    private boolean isBaggageExempt(String tier) {
        return SILVER.equals(tier) || GOLD.equals(tier);
    }
}

public class facade_250103133 {
    public static void main(String[] args) {
        FlightBookingFacade bookingFacade = new FlightBookingFacade();

        System.out.println("=== TEST A: Valid Booking (EUR) ===");
        String ticketA = bookingFacade.bookFlight(
                "Amina Suleimenova", "KZ204", "14B", 320.00, 2, 24.5, "EUR", "4532015112830366");
        System.out.println("Result A: " + ticketA + "\n");

        System.out.println("=== TEST B: Blocked Seat (Row 13) ===");
        String ticketB = bookingFacade.bookFlight(
                "Daniyar Kassymov", "KZ204", "13A", 320.00, 1, 15.0, "USD", "4532015112830366");
        System.out.println("Result B: " + ticketB + "\n");

        System.out.println("=== TEST C: Payment Failure & Seat Rollback ===");
        String ticketC = bookingFacade.bookFlight(
                "Timur Bekov", "KZ204", "08C", 320.00, 1, 18.0, "KZT", "1234");
        System.out.println("Result C: " + ticketC + "\n");

        System.out.println("=== TEST 4: Silver Tier (No Baggage Fee, Promo Applied) ===");
        String ticket4 = bookingFacade.bookFlight(
                "Madina Serikova", "KZ204", "21F", 320.00, 3, 30.0, "USD", "4532015112830366", "SILVER");
        System.out.println("Result 4: " + ticket4 + "\n");
    }
}
